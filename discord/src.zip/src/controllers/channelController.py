from services.channelService import (
    create_channel, join_channel, send_message, get_channel_info,
    get_joined_channels, get_hosted_channels, delete_channel, get_all_channels, 
    approve_join_request, get_join_requests, reject_join_request, send_message_p2p
)

def create_channel_controller(data):
    host = data.get("host")
    channel_name = data.get("channel_name")
    is_private = data.get("is_private", False)
    allow_visitor = data.get("allow_visitor", False)
    if not host or not channel_name:
        return {"status": "error", "message": "Missing parameters"}
    result = create_channel(host, channel_name, is_private, allow_visitor)
    return result

def approve_join_request_controller(data):
    owner = data.get("owner")
    channel_name = data.get("channel_name")
    target_user = data.get("target_user")
    if not owner or not channel_name or not target_user:
        return {"status": "error", "message": "Missing parameters"}
    result = approve_join_request(owner, channel_name, target_user)
    return result

def reject_join_request_controller(data):
    owner = data.get("owner")
    channel_name = data.get("channel_name")
    target_user = data.get("target_user")

    if not owner or not channel_name or not target_user:
        return {"status": "error", "message": "Missing parameters"}

    from services.channelService import reject_join_request
    result = reject_join_request(owner, channel_name, target_user)
    return result

def get_join_requests_controller(data):
    owner = data.get("owner")
    channel_name = data.get("channel_name")

    if not owner or not channel_name:
        return {"status": "error", "message": "Missing parameters"}

    return get_join_requests(owner, channel_name)

def join_channel_controller(data):
    username = data.get("username")
    channel_name = data.get("channel_name")
    if not username or not channel_name:
        return {"status": "error", "message": "Missing parameters"}
    result = join_channel(username, channel_name)
    return result

def get_user_channels_controller(data):
    username = data.get("username")
    if not username:
        return {"status": "error", "message": "Missing parameters"}
    joined_result = get_joined_channels(username)
    hosted_result = get_hosted_channels(username)
    if joined_result["status"] == "error" or hosted_result["status"] == "error":
        return {"status": "error", "message": "User not found"}
    return {
        "status": "success",
        "data": {
            "joined_channels": joined_result.get("joined_channels", []),
            "hosted_channels": hosted_result.get("hosted_channels", [])
        }
    }

def get_hosted_channels_controller(data):
    username = data.get("username")
    if not username:
         return {"status": "error", "message": "Missing parameters"}
    hosted_result = get_hosted_channels(username)
    if hosted_result["status"] == "error":
        return {"status": "error", "message": "User not found"}
    return {
        "status": "success",
        "data": {
            "hosted_channels": hosted_result.get("hosted_channels", [])
        }
    }

def send_message_controller(data):
    username = data.get("username")
    channel_name = data.get("channel_name")
    message_text = data.get("message")
    if not username or not channel_name or not message_text:
        return {"status": "error", "message": "Missing parameters"}
    result = send_message(username, channel_name, message_text)
    return result

def send_message_p2p_controller(data):
    username = data.get("username")
    channel_name = data.get("channel_name")
    message_text = data.get("message")
    if not username or not channel_name or not message_text:
        return {"status": "error", "message": "Missing parameters"}
    result = send_message_p2p(username, channel_name, message_text)
    return result

def get_channel_info_controller(data):
    channel_name = data.get("channel_name")
    username = data.get("username")
    if not channel_name or not username:
        return {"status": "error", "message": "Missing parameters"}
    result = get_channel_info(channel_name, username)
    is_visitor = data.get("is_visitor", False)
    if result.get("status") == "success" and is_visitor and not result.get("allow_visitor", True):
         return {"status": "error", "message": "This channel does not allow visitor viewing operation"}
    return result

def delete_channel_controller(data):
    username = data.get("username")
    channel_name = data.get("channel_name")
    if not username or not channel_name:
        return {"status": "error", "message": "Missing parameters"}
    result = delete_channel(username, channel_name)
    return result

def get_all_channels_controller(data):
    result = get_all_channels()
    return result

# Hỗ trợ truy vấn danh sách các phiên đăng nhập của người dùng
def get_all_users_controller(data):
    from services.authService import get_all_users
    return get_all_users()
